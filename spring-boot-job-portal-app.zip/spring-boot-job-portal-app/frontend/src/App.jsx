// src/App.jsx
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Home from "./pages/Home";
import CreatePost from "./pages/CreatePost";
import Feed from "./pages/Feed";
import Dashboard from "./pages/Dashboard";
import RecruiterDashboard from "./pages/RecruiterDashboard";
import Layout from "./components/Layout";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import Register from "./pages/Register";

// Protect routes that require login
function ProtectedRoute({ children, role }) {
  const token = localStorage.getItem("token");
  const user = token ? JSON.parse(localStorage.getItem("user") || "{}") : null;

  if (!token || !user) return <Navigate to="/login" replace />;

  if (role && user.role.toLowerCase() !== role.toLowerCase()) {
    return user.role.toLowerCase() === "recruiter" ? (
      <Navigate to="/recruiter/dashboard" replace />
    ) : (
      <Navigate to="/employee/feed" replace />
    );
  }

  return children;
}

// Redirect logged-in users from login/register
function AuthRedirect({ children }) {
  const token = localStorage.getItem("token");
  if (!token) return children;

  try {
    const user = JSON.parse(localStorage.getItem("user") || "{}");
    if (user.role?.toLowerCase() === "recruiter") {
      return <Navigate to="/recruiter/dashboard" replace />;
    }
    if (user.role?.toLowerCase() === "applicant") {
      return <Navigate to="/employee/feed" replace />;
    }
  } catch (e) {
    localStorage.clear();
  }
  return children;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout><Home /></Layout>} />
        <Route path="/login" element={<AuthRedirect><Login /></AuthRedirect>} />
        <Route path="/register" element={<AuthRedirect><Register /></AuthRedirect>} />
        
        {/* Applicant Routes */}
        <Route 
          path="/employee/feed" 
          element={
            <ProtectedRoute role="applicant">
              <Layout><Feed /></Layout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/dashboard" 
          element={
            <ProtectedRoute role="applicant">
              <Layout><Dashboard /></Layout>
            </ProtectedRoute>
          } 
        />
        
        {/* Recruiter Routes */}
        <Route 
          path="/create-job-post" 
          element={
            <ProtectedRoute role="recruiter">
              <Layout><CreatePost /></Layout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/recruiter/dashboard" 
          element={
            <ProtectedRoute role="recruiter">
              <Layout><RecruiterDashboard /></Layout>
            </ProtectedRoute>
          } 
        />
        
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}