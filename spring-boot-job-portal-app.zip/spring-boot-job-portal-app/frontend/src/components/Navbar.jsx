// src/components/Navbar.jsx
import { Link, useNavigate, useLocation } from "react-router-dom";

export default function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();

  const token = localStorage.getItem("token");
  const user = token ? JSON.parse(localStorage.getItem("user") || "{}") : null;

  const isApplicant = token && user?.role === "applicant";
  const isRecruiter = token && user?.role === "recruiter";

  // FIXED: Correct paths
  const isOnApplicantFeed = location.pathname === "/employee/feed";
  const isOnRecruiterDashboard = location.pathname === "/recruiter/dashboard";
  const isOnApplicantDashboard = location.pathname === "/dashboard";
  const isOnDashboard = isOnApplicantDashboard || isOnRecruiterDashboard;

  const logout = () => {
    localStorage.clear();
    navigate("/login", { replace: true });
  };

  return (
    <nav className="fixed top-0 w-full bg-white shadow-md z-50">
      <div className="max-w-7xl mx-auto flex justify-between items-center px-6 py-4">
        <h1
          className="text-2xl font-bold cursor-pointer text-blue-700"
          onClick={() => navigate("/")}
        >
          JobPortal
        </h1>

        <div className="flex gap-4 items-center">
          {/* NOT LOGGED IN */}
          {!token && (
            <>
              <Link to="/login" className="text-gray-700 hover:text-blue-700 font-semibold">
                Login
              </Link>
              <Link to="/register" className="text-gray-700 hover:text-blue-700 font-semibold">
                Register
              </Link>
            </>
          )}

          {/* LOGGED IN */}
          {token && (
            <>
              {/* APPLICANT: Job Feed */}
              {isApplicant && !isOnApplicantFeed && !isOnApplicantDashboard && (
                <button
                  onClick={() => navigate("/employee/feed")}
                  className="text-gray-700 hover:text-blue-700 font-semibold"
                >
                  Job Feed
                </button>
              )}

              {/* RECRUITER: Create Job */}
              {isRecruiter && !isOnRecruiterDashboard && (
                <button
                  onClick={() => navigate("/create-job-post")}
                  className="text-gray-700 hover:text-blue-700 font-semibold"
                >
                  Create Job
                </button>
              )}

              {/* DASHBOARD */}
              {!isOnDashboard && (
                <button
                  onClick={() =>
                    navigate(isRecruiter ? "/recruiter/dashboard" : "/dashboard")
                  }
                  className="text-gray-700 hover:text-blue-700 font-semibold"
                >
                  Dashboard
                </button>
              )}

              {/* LOGOUT */}
              <button
                onClick={logout}
                className="bg-red-500 text-white px-3 py-1 rounded-md hover:bg-red-600"
              >
                Logout
              </button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}