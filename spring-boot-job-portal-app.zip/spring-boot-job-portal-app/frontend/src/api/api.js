// src/api/api.js
const API_BASE_URL = 'http://localhost:8080';

const apiRequest = async (endpoint, options = {}) => {
  const url = `${API_BASE_URL}${endpoint}`;
  const config = {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  };

  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  try {
    const response = await fetch(url, config);
    const contentType = response.headers.get('content-type');
    
    // ❌ ERROR HANDLING - Handle both JSON and plain text errors
    if (!response.ok) {
      let errorMessage = `HTTP error! status: ${response.status}`;
      
      if (contentType?.includes('application/json')) {
        try {
          const errorData = await response.json();
          errorMessage = errorData.message || errorData.error || errorMessage;
        } catch {
          // Fall through to default
        }
      } else {
        // ✅ FIXED: Handle plain text error responses
        try {
          const errorText = await response.text();
          if (errorText.includes('already exists') || errorText.includes('duplicate')) {
            errorMessage = 'User already exists. Please use a different email.';
          } else if (errorText.includes('validation')) {
            errorMessage = 'Please check your input data and try again.';
          } else {
            errorMessage = errorText || errorMessage;
          }
        } catch {
          // Use default message
        }
      }
      
      throw new Error(errorMessage);
    }

    // ✅ SUCCESS HANDLING - Handle both JSON and plain text responses
    if (contentType?.includes('application/json')) {
      const data = await response.json();
      // Handle different backend response formats
      if (data.success !== false && !data.error) {
        return data.data || data.applications || data.jobs || data || [];
      } else {
        throw new Error(data.message || data.error || 'Request failed');
      }
    } else {
      // ✅ FIXED: Handle plain text success responses (like "Registered successfully")
      const textResponse = await response.text();
      return {
        success: true,
        message: textResponse,
        data: textResponse
      };
    }
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};

// ==================== AUTH EXPORTS ====================
export const registerUser = (userData) => 
  apiRequest('/auth/register', { method: 'POST', body: JSON.stringify(userData) });

export const loginUser = (userData) => 
  apiRequest('/auth/login', { method: 'POST', body: JSON.stringify(userData) });

// ==================== JOB EXPORTS ====================
export const getJobs = () => apiRequest('/job-posts');
export const searchJobs = (text) => apiRequest(`/job-posts/search/${encodeURIComponent(text)}`);
export const createJobPost = (jobData) => 
  apiRequest('/create-job-post', { method: 'POST', body: JSON.stringify(jobData) });
export const getMyJobs = () => apiRequest('/job-posts/my');

// ==================== APPLICATION EXPORTS ====================
export const getAppliedJobs = () => apiRequest('/jobs/applied');
export const applyJob = (jobId, formData) => 
  apiRequest(`/jobs/apply/${jobId}`, { method: 'POST', body: JSON.stringify(formData) });
export const deleteApplication = (applicationId) => 
  apiRequest(`/jobs/applied/${applicationId}`, { method: 'DELETE' });
export const updateApplicationStatus = (applicationId, statusData) => 
  apiRequest(`/jobs/applications/${applicationId}/status`, { 
    method: 'PUT', 
    body: JSON.stringify(statusData) 
  });
export const getJobApplications = (jobId) => 
  apiRequest(`/jobs/${jobId}/applications`);

// ==================== ALTERNATIVE NAMING ====================
export const login = loginUser;
export const register = registerUser;