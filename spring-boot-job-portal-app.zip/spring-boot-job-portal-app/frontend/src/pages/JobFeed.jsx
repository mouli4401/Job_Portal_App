// src/pages/Dashboard.jsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAppliedJobs } from "../api/api";

export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [appliedJobs, setAppliedJobs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userData = localStorage.getItem("user");

    if (!token || !userData) {
      navigate("/login");
      return;
    }

    let parsedUser;
    try {
      parsedUser = JSON.parse(userData);
    } catch {
      localStorage.clear();
      navigate("/login");
      return;
    }

    if (parsedUser.role !== "applicant") {
      navigate("/recruiter/dashboard");
      return;
    }

    setUser(parsedUser);

    (async () => {
      try {
        const res = await getAppliedJobs(token);
        setAppliedJobs(Array.isArray(res) ? res : []);
      } catch (err) {
        console.error("Failed to load applied jobs:", err);
        setAppliedJobs([]);
      } finally {
        setLoading(false);
      }
    })();
  }, [navigate]);

  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-10 px-4">
      <div className="max-w-4xl mx-auto">

        <div className="bg-white shadow rounded-lg p-6 mb-6 flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-800">My Dashboard</h1>
          <button
            onClick={logout}
            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition"
          >
            Logout
          </button>
        </div>

        <div className="bg-white shadow rounded-lg p-6 mb-6">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">Profile</h2>
          <div className="space-y-2 text-gray-700">
            <p><strong>Email:</strong> {user.email}</p>
            <p><strong>Role:</strong> <span className="text-blue-600 font-medium capitalize">{user.role}</span></p>
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">Applied Jobs</h2>

          {loading ? (
            <p className="text-gray-500">Loading...</p>
          ) : appliedJobs.length === 0 ? (
            <p className="text-gray-500 italic">No applications yet.</p>
          ) : (
            <div className="space-y-4">
              {appliedJobs.map((job) => (
                <div
                  key={job.jobId}
                  className="border border-gray-200 p-5 rounded-lg bg-gray-50 hover:bg-gray-100 transition"
                >
                  <h3 className="font-semibold text-lg text-blue-700 mb-1">
                    {job.profile}
                  </h3>
                  <p className="text-gray-600 text-sm mb-2 line-clamp-2">{job.desc}</p>
                  <p className="text-sm text-gray-700">
                    <strong>Exp:</strong> {job.exp === 0 ? "Fresher" : `${job.exp}+ years`}
                  </p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {job.techs?.map((t, i) => (
                      <span
                        key={i}
                        className="bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}