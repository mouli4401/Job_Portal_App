// src/pages/CreatePost.jsx
import { useState } from "react";
import { createJobPost } from "../api/api";
import { useNavigate } from "react-router-dom";

const CreatePost = () => {
  const [form, setForm] = useState({
    profile: "",
    desc: "",
    exp: "",
    techs: "",
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    const { profile, desc, exp, techs } = form;

    if (!profile.trim() || !desc.trim() || !exp.trim() || !techs.trim()) {
      alert("All fields are required.");
      return;
    }

    const experience = parseInt(exp);
    if (isNaN(experience) || experience < 0) {
      alert("Experience must be a number >= 0.");
      return;
    }

    const newJob = {
      profile: profile.trim(),
      desc: desc.trim(),
      exp: experience,
      techs: techs.split(",").map((tech) => tech.trim()).filter(Boolean),
    };

    try {
      setLoading(true);
      const token = localStorage.getItem("token");
      await createJobPost(newJob, token); // ✅ FIXED: Pass token
      alert("Job post created successfully! 🎉");
      navigate("/recruiter/dashboard");
    } catch (err) {
      console.error(err);
      alert("Failed to create job post: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center px-4 pb-4 pt-24">
      <div className="w-full max-w-2xl bg-white shadow-lg rounded-xl px-8 py-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
          Create Job Post
        </h2>
        <div className="space-y-4">
          <div>
            <label className="block text-gray-600 mb-1">Job Title *</label>
            <input
              type="text"
              name="profile"
              placeholder="Frontend Developer"
              value={form.profile}
              onChange={handleChange}
              disabled={loading}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400 disabled:bg-gray-100"
            />
          </div>
          <div>
            <label className="block text-gray-600 mb-1">Job Description *</label>
            <textarea
              name="desc"
              rows="4"
              placeholder="Describe the job role"
              value={form.desc}
              onChange={handleChange}
              disabled={loading}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400 resize-none disabled:bg-gray-100"
            />
          </div>
          <div>
            <label className="block text-gray-600 mb-1">
              Experience Required * (years)
            </label>
            <input
              type="number"
              name="exp"
              min="0"
              placeholder="e.g. 2"
              value={form.exp}
              onChange={handleChange}
              disabled={loading}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400 disabled:bg-gray-100"
            />
          </div>
          <div>
            <label className="block text-gray-600 mb-1">
              Technologies * (comma separated)
            </label>
            <input
              type="text"
              name="techs"
              placeholder="e.g. React, Node.js, MongoDB"
              value={form.techs}
              onChange={handleChange}
              disabled={loading}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400 disabled:bg-gray-100"
            />
          </div>
        </div>
        <div className="mt-6 text-center">
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-200 font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {loading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Creating Job...
              </>
            ) : (
              'Create Job Post'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreatePost;