// src/pages/RecruiterDashboard.jsx
import React, { useState, useEffect } from 'react';
import { getMyJobs, getJobApplications, updateApplicationStatus } from '../api/api';

export default function RecruiterDashboard() {
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('jobs');
  const [selectedJobId, setSelectedJobId] = useState(null);
  const [updatingStatus, setUpdatingStatus] = useState({});

  const loadJobs = async () => {
    try {
      setLoading(true);
      const data = await getMyJobs();
      setJobs(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Error loading jobs:', error);
      alert('Error loading jobs: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const loadJobApplications = async (jobId) => {
    try {
      const data = await getJobApplications(jobId);
      setApplications(Array.isArray(data) ? data : []);
      setSelectedJobId(jobId);
      setActiveTab('applications');
    } catch (error) {
      console.error('Error loading applications:', error);
      alert('Error loading applications: ' + error.message);
    }
  };

  const handleStatusUpdate = async (applicationId, newStatus, notes = '') => {
    setUpdatingStatus(prev => ({ ...prev, [applicationId]: true }));
    
    try {
      await updateApplicationStatus(applicationId, { status: newStatus, notes });
      
      // Refresh applications
      if (selectedJobId) {
        const updatedApps = await getJobApplications(selectedJobId);
        setApplications(Array.isArray(updatedApps) ? updatedApps : []);
      }
      
      alert('Status updated successfully! ✅');
    } catch (error) {
      console.error('Error updating status:', error);
      alert('Error updating status: ' + error.message);
    } finally {
      setUpdatingStatus(prev => ({ ...prev, [applicationId]: false }));
    }
  };

  useEffect(() => {
    loadJobs();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-xl font-semibold text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Recruiter Dashboard</h1>
          <p className="text-xl text-gray-600">Manage your job postings and review applications</p>
        </div>

        {/* Tabs */}
        <div className="flex bg-white rounded-xl shadow-sm border border-gray-200 mb-8 overflow-hidden">
          <button
            onClick={() => setActiveTab('jobs')}
            className={`flex-1 py-4 px-6 font-semibold transition-all duration-300 ${
              activeTab === 'jobs'
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg'
                : 'text-gray-700 hover:text-gray-900 hover:bg-gray-50'
            }`}
          >
            My Jobs ({jobs.length})
          </button>
          {activeTab === 'applications' && (
            <button
              onClick={() => {
                setActiveTab('jobs');
                setApplications([]);
                setSelectedJobId(null);
              }}
              className="py-4 px-6 text-sm font-medium text-blue-600 hover:text-blue-700 hover:bg-gray-50 transition-colors"
            >
              ← Back to Jobs
            </button>
          )}
        </div>

        {activeTab === 'jobs' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {jobs.length === 0 ? (
              <div className="col-span-full text-center py-20">
                <svg className="mx-auto h-24 w-24 text-gray-400 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <h3 className="text-2xl font-semibold text-gray-900 mb-2">No jobs posted yet</h3>
                <p className="text-gray-500 mb-6">Create your first job post to start receiving applications</p>
                <a href="/create-job-post" className="inline-flex items-center px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-all duration-300 font-semibold">
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  Post a Job
                </a>
              </div>
            ) : (
              jobs.map((job) => {
                const appCount = applications.filter(app => app.jobId === job.id).length;
                
                return (
                  <div key={job.id} className="bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden border border-gray-200">
                    <div className="p-8">
                      <h3 className="text-2xl font-bold text-gray-900 mb-4">{job.profile}</h3>
                      <p className="text-gray-600 mb-6 line-clamp-3">{job.desc}</p>
                      
                      <div className="flex flex-wrap gap-2 mb-6">
                        {job.techs?.map((tech, index) => (
                          <span key={index} className="px-3 py-1 bg-gradient-to-r from-indigo-500 to-purple-600 text-white text-sm rounded-full">
                            {tech}
                          </span>
                        ))}
                      </div>

                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-500">
                          Experience: {job.exp === 0 ? "Fresher" : `${job.exp}+ years`}
                        </span>
                        <div className="flex items-center gap-3">
                          <span className="px-4 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 text-white text-sm font-semibold rounded-full shadow-sm">
                            {appCount} Applications
                          </span>
                          <button
                            onClick={() => loadJobApplications(job.id)}
                            className="px-6 py-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white text-sm font-semibold rounded-xl hover:from-green-700 hover:to-emerald-700 shadow-sm hover:shadow-md transition-all duration-300"
                          >
                            View Applications
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {activeTab === 'applications' && selectedJobId && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">
              Job Applications ({applications.length})
            </h2>
            
            <div className="space-y-6">
              {applications.map((application) => (
                <div key={application.id} className="border border-gray-200 rounded-xl p-6 bg-gradient-to-r from-gray-50 to-white hover:shadow-sm transition-all duration-300">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">{application.userName}</h4>
                      <p className="text-sm text-gray-600">{application.userEmail}</p>
                      <p className="text-sm text-gray-500 mt-1">
                        Applied: {new Date(application.appliedDate).toLocaleDateString()}
                      </p>
                    </div>
                    <span className={`px-4 py-2 rounded-full text-sm font-semibold ${
                      application.status === 'ACCEPTED'
                        ? 'bg-green-100 text-green-800 border border-green-200'
                        : application.status === 'REJECTED'
                        ? 'bg-red-100 text-red-800 border border-red-200'
                        : application.status === 'REVIEWED'
                        ? 'bg-yellow-100 text-yellow-800 border border-yellow-200'
                        : 'bg-blue-100 text-blue-800 border border-blue-200'
                    }`}>
                      {application.status}
                    </span>
                  </div>

                  {application.coverLetter && (
                    <div className="mb-6">
                      <h5 className="font-medium text-gray-900 mb-3">Cover Letter</h5>
                      <p className="text-sm text-gray-600 bg-white p-4 rounded-lg border border-gray-200 line-clamp-4">
                        {application.coverLetter}
                      </p>
                    </div>
                  )}

                  <div className="flex flex-wrap gap-2 mb-6">
                    {application.technologies?.map((tech, index) => (
                      <span key={index} className="px-3 py-1 bg-indigo-100 text-indigo-800 text-xs rounded-full font-medium">
                        {tech}
                      </span>
                    ))}
                  </div>

                  {application.resumeUrl && (
                    <div className="mb-6">
                      <a
                        href={application.resumeUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-sm rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-sm hover:shadow-md"
                      >
                        <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                        View Resume
                      </a>
                    </div>
                  )}

                  {application.recruiterNotes && (
                    <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <h5 className="font-medium text-yellow-800 mb-2">Recruiter Notes</h5>
                      <p className="text-sm text-yellow-700">{application.recruiterNotes}</p>
                    </div>
                  )}

                  <div className="flex flex-col sm:flex-row gap-4 pt-4 border-t border-gray-100">
                    <select
                      value={application.status}
                      onChange={(e) => handleStatusUpdate(application.id, e.target.value)}
                      disabled={updatingStatus[application.id]}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100 disabled:cursor-not-allowed"
                    >
                      <option value="PENDING">Pending</option>
                      <option value="REVIEWED">Reviewed</option>
                      <option value="ACCEPTED">Accepted</option>
                      <option value="REJECTED">Rejected</option>
                    </select>
                    <input
                      type="text"
                      placeholder="Add notes (optional)"
                      defaultValue={application.recruiterNotes || ''}
                      onBlur={(e) => handleStatusUpdate(application.id, application.status, e.target.value)}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>
              ))}
            </div>

            {applications.length === 0 && (
              <div className="text-center py-12">
                <svg className="mx-auto h-16 w-16 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No applications yet</h3>
                <p className="text-gray-500">Applications will appear here once candidates apply to this job</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}