package com.mahmudalam.jobportal.spring_boot_job_portal_app.controller;

import com.mahmudalam.jobportal.spring_boot_job_portal_app.interfaces.*;
import com.mahmudalam.jobportal.spring_boot_job_portal_app.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;  // ✅ This imports EVERYTHING needed
import java.util.stream.Collectors;  // ✅ CRITICAL for stream()

@RestController
@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:3000", "http://localhost:3001"})
public class JobPostController {

    @Autowired JobPostRepository repo;
    @Autowired SearchRepository search_repo;
    @Autowired AppliedJobRepository appliedRepo;
    @Autowired UserRepo userRepo;
    @Autowired JwtUtil jwtUtil;
    @Autowired private MongoTemplate mongoTemplate;

    /* -------------------------------------------------
       1. GET ALL JOBS WITH APPLICATION COUNTS ✅ FIXED
       ------------------------------------------------- */
    @GetMapping("/job-posts")
    public ResponseEntity<List<Map<String, Object>>> getAllJobPosts(HttpServletRequest request) {
        try {
            String token = request.getHeader("Authorization");
            List<JobPostModel> allJobs = repo.findAll();
            List<Map<String, Object>> jobsWithCount = new ArrayList<>();

            if (token == null || !token.startsWith("Bearer ")) {
                for (JobPostModel job : allJobs) {
                    long count = appliedRepo.countByJobId(job.getId());
                    Map<String, Object> jobData = createJobData(job, count);
                    jobsWithCount.add(jobData);
                }
                return ResponseEntity.ok(jobsWithCount);
            }

            token = token.substring(7);
            String email = jwtUtil.extractUsername(token);
            User user = userRepo.findByEmail(email);

            if (user == null) {
                for (JobPostModel job : allJobs) {
                    long count = appliedRepo.countByJobId(job.getId());
                    Map<String, Object> jobData = createJobData(job, count);
                    jobsWithCount.add(jobData);
                }
                return ResponseEntity.ok(jobsWithCount);
            }

            // ✅ FIXED: SIMPLE WAY - NO STREAM ERRORS
            List<String> appliedIds = new ArrayList<>();
            List<AppliedJob> userApplications = appliedRepo.findByUserId(user.getId());
            if (userApplications != null) {
                for (AppliedJob app : userApplications) {
                    if (app.getJobId() != null) {
                        appliedIds.add(app.getJobId());
                    }
                }
            }

            for (JobPostModel job : allJobs) {
                if (!appliedIds.contains(job.getId())) {
                    long count = appliedRepo.countByJobId(job.getId());
                    Map<String, Object> jobData = createJobData(job, count);
                    jobsWithCount.add(jobData);
                }
            }

            return ResponseEntity.ok(jobsWithCount);
        } catch (Exception e) {
            e.printStackTrace();
            List<Map<String, Object>> jobsWithCount = new ArrayList<>();
            for (JobPostModel job : repo.findAll()) {
                long count = appliedRepo.countByJobId(job.getId());
                Map<String, Object> jobData = createJobData(job, count);
                jobsWithCount.add(jobData);
            }
            return ResponseEntity.ok(jobsWithCount);
        }
    }

    private Map<String, Object> createJobData(JobPostModel job, long count) {
        Map<String, Object> jobData = new HashMap<>();
        jobData.put("id", job.getId());
        jobData.put("profile", job.getProfile());
        jobData.put("desc", job.getDesc());
        jobData.put("exp", job.getExp());
        jobData.put("techs", job.getTechs());
        jobData.put("applicationCount", count);
        return jobData;
    }

    /* -------------------------------------------------
       2. SEARCH JOBS
       ------------------------------------------------- */
    @GetMapping("/job-posts/search/{text}")
    public ResponseEntity<List<JobPostModel>> search(@PathVariable String text) {
        return ResponseEntity.ok(search_repo.findByText(text));
    }

    /* -------------------------------------------------
       3. CREATE JOB POST
       ------------------------------------------------- */
    @PostMapping("/create-job-post")
    public ResponseEntity<Map<String, Object>> createJobPost(@RequestBody JobPostModel job,
                                                             HttpServletRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            String auth = request.getHeader("Authorization");
            if (auth == null || !auth.startsWith("Bearer ")) {
                response.put("success", false);
                response.put("message", "Unauthorized");
                return ResponseEntity.status(401).body(response);
            }

            String token = auth.substring(7);
            String email = jwtUtil.extractUsername(token);
            User user = userRepo.findByEmail(email);
            if (user == null || !"recruiter".equalsIgnoreCase(user.getRole())) {
                response.put("success", false);
                response.put("message", "Access denied");
                return ResponseEntity.status(403).body(response);
            }

            job.setPostedBy(user.getId());
            JobPostModel saved = repo.save(job);

            response.put("success", true);
            response.put("message", "Job posted successfully");
            response.put("job", saved);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("success", false);
            response.put("message", "Error creating job post");
            return ResponseEntity.status(500).body(response);
        }
    }

    /* -------------------------------------------------
       4. APPLY TO JOB ✅ SIMPLIFIED & 100% FIXED
       ------------------------------------------------- */
    @PostMapping("/jobs/apply/{jobId}")
    public ResponseEntity<Map<String, Object>> applyJobWithForm(
            @PathVariable String jobId,
            @RequestBody Map<String, String> formData,
            HttpServletRequest request) {
        Map<String, Object> response = new HashMap<>();

        try {
            String token = request.getHeader("Authorization");
            String email = "anonymous";

            if (token != null && token.startsWith("Bearer ")) {
                token = token.substring(7);
                email = jwtUtil.extractUsername(token);
            }

            User user = userRepo.findByEmail(email);
            if (user == null) {
                response.put("success", false);
                response.put("message", "User not found. Please login first.");
                return ResponseEntity.status(401).body(response);
            }

            Optional<JobPostModel> jobOpt = repo.findById(jobId);
            if (jobOpt.isEmpty()) {
                response.put("success", false);
                response.put("message", "Job not found");
                return ResponseEntity.status(404).body(response);
            }

            JobPostModel job = jobOpt.get();

            // Check if already applied
            Optional<AppliedJob> existingOpt = appliedRepo.findByUserIdAndJobId(user.getId(), jobId);
            if (existingOpt.isPresent()) {
                response.put("success", false);
                response.put("message", "You have already applied to this job");
                return ResponseEntity.status(400).body(response);
            }

            // Create new application
            AppliedJob application = new AppliedJob();
            application.setUserId(user.getId());
            application.setUserName(user.getName());
            application.setUserEmail(user.getEmail());
            application.setJobId(jobId);
            application.setJobTitle(job.getProfile());
            application.setJobDescription(job.getDesc());
            application.setExperience(job.getExp());
            
            // ✅ ULTRA-SIMPLE & 100% SAFE setTechnologies
            List<String> technologies = new ArrayList<>();
            try {
                Object techs = job.getTechs();
                if (techs != null) {
                    if (techs instanceof List) {
                        technologies.addAll((List<String>) techs);
                    } else {
                        technologies.add(techs.toString());
                    }
                }
            } catch (Exception e) {
                // If any error, just use empty list
                System.out.println("Techs conversion error: " + e.getMessage());
            }
            application.setTechnologies(technologies);
            
            application.setCoverLetter(formData.get("coverLetter"));
            application.setResumeUrl(formData.get("resumeUrl"));
            application.setStatus("PENDING");
            application.setAppliedDate(new Date());

            AppliedJob savedApplication = appliedRepo.save(application);

            response.put("success", true);
            response.put("message", "Application submitted successfully! 🎉");
            response.put("applicationId", savedApplication.getId());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            e.printStackTrace();
            response.put("success", false);
            response.put("message", "Error applying to job: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    /* -------------------------------------------------
       5. GET APPLIED JOBS
       ------------------------------------------------- */
    @GetMapping("/jobs/applied")
    public ResponseEntity<Map<String, Object>> getAppliedJobs(HttpServletRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            String auth = request.getHeader("Authorization");
            if (auth == null || !auth.startsWith("Bearer ")) {
                response.put("success", false);
                response.put("message", "Unauthorized");
                return ResponseEntity.status(401).body(response);
            }
            String token = auth.substring(7);
            String email = jwtUtil.extractUsername(token);
            User user = userRepo.findByEmail(email);
            if (user == null) {
                response.put("success", false);
                response.put("message", "User not found");
                return ResponseEntity.status(401).body(response);
            }
            List<AppliedJob> jobs = appliedRepo.findByUserId(user.getId());
            response.put("success", true);
            response.put("applications", jobs != null ? jobs : new ArrayList<>());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("success", false);
            response.put("message", "Error fetching applications");
            return ResponseEntity.status(500).body(response);
        }
    }

    /* -------------------------------------------------
       6. GET MY POSTED JOBS
       ------------------------------------------------- */
    @GetMapping("/job-posts/my")
    public ResponseEntity<Map<String, Object>> getMyJobs(HttpServletRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            String auth = request.getHeader("Authorization");
            if (auth == null || !auth.startsWith("Bearer ")) {
                response.put("success", false);
                response.put("message", "Unauthorized");
                return ResponseEntity.status(401).body(response);
            }

            String token = auth.substring(7);
            String email = jwtUtil.extractUsername(token);
            User user = userRepo.findByEmail(email);
            if (user == null || !"recruiter".equalsIgnoreCase(user.getRole())) {
                response.put("success", false);
                response.put("message", "Access denied");
                return ResponseEntity.status(403).body(response);
            }

            Query q = new Query(Criteria.where("postedBy").is(user.getId()));
            List<JobPostModel> list = mongoTemplate.find(q, JobPostModel.class);

            response.put("success", true);
            response.put("jobs", list);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("success", false);
            response.put("message", "Error fetching jobs");
            return ResponseEntity.status(500).body(response);
        }
    }

    /* -------------------------------------------------
       7. DELETE APPLICATION
       ------------------------------------------------- */
    @DeleteMapping("/jobs/applied/{applicationId}")
    public ResponseEntity<Map<String, Object>> deleteApplication(@PathVariable String applicationId) {
        Map<String, Object> response = new HashMap<>();
        try {
            if (appliedRepo.existsById(applicationId)) {
                appliedRepo.deleteById(applicationId);
                response.put("success", true);
                response.put("message", "Application deleted successfully");
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("message", "Application not found");
                return ResponseEntity.status(404).body(response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.put("success", false);
            response.put("message", "Error deleting application");
            return ResponseEntity.status(500).body(response);
        }
    }

    /* -------------------------------------------------
       8. UPDATE APPLICATION STATUS
       ------------------------------------------------- */
    @PutMapping("/jobs/applications/{applicationId}/status")
    public ResponseEntity<Map<String, Object>> updateApplicationStatus(
            @PathVariable String applicationId,
            @RequestBody Map<String, String> request) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<AppliedJob> applicationOpt = appliedRepo.findById(applicationId);
            if (applicationOpt.isEmpty()) {
                response.put("success", false);
                response.put("message", "Application not found");
                return ResponseEntity.status(404).body(response);
            }

            AppliedJob application = applicationOpt.get();
            String status = request.get("status");
            String notes = request.get("notes");

            // Simple validation
            if (status == null || (!"PENDING".equals(status) && !"REVIEWED".equals(status) && 
                                   !"ACCEPTED".equals(status) && !"REJECTED".equals(status))) {
                response.put("success", false);
                response.put("message", "Invalid status");
                return ResponseEntity.badRequest().body(response);
            }

            String previousStatus = application.getStatus();
            application.setStatus(status);
            application.setRecruiterNotes(notes);
            application.setUpdatedDate(new Date());
            appliedRepo.save(application);

            String notificationMessage = "";
            if ("ACCEPTED".equals(status)) {
                notificationMessage = "🎉 Congratulations! Your application has been ACCEPTED!";
            } else if ("REJECTED".equals(status)) {
                notificationMessage = "📋 Your application has been REVIEWED but unfortunately REJECTED.";
            } else if ("REVIEWED".equals(status)) {
                notificationMessage = "✅ Your application is under REVIEW. We'll get back to you soon!";
            }

            response.put("success", true);
            response.put("message", "Status updated successfully");
            response.put("application", application);
            response.put("notificationMessage", notificationMessage);
            response.put("statusChanged", !status.equals(previousStatus));

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("success", false);
            response.put("message", "Error updating status");
            return ResponseEntity.status(500).body(response);
        }
    }

    /* -------------------------------------------------
       9. GET APPLICATIONS BY JOB ID
       ------------------------------------------------- */
    @GetMapping("/jobs/{jobId}/applications")
    public ResponseEntity<Map<String, Object>> getJobApplications(@PathVariable String jobId) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<AppliedJob> applications = appliedRepo.findByJobId(jobId);
            response.put("success", true);
            response.put("applications", applications != null ? applications : new ArrayList<>());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("success", false);
            response.put("message", "Error fetching applications");
            return ResponseEntity.status(500).body(response);
        }
    }
}