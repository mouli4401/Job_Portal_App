package com.mahmudalam.jobportal.spring_boot_job_portal_app.controller;

import com.mahmudalam.jobportal.spring_boot_job_portal_app.interfaces.UserRepo;
import com.mahmudalam.jobportal.spring_boot_job_portal_app.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class AuthService {

    @Autowired
    private UserRepo repo;

    @Autowired
    private JwtUtil jwtUtil;

    public String register(User user) {
        User existingUser = repo.findByEmail(user.getEmail());
        if (existingUser != null) {
            return "User already exists!";
        }

        // Hash password
        user.setPassword(BCrypt.hashpw(user.getPassword(), BCrypt.gensalt()));
        repo.save(user);
        return "Registered Successfully";
    }

    public Map<String, Object> login(String email, String password) {
        Map<String, Object> response = new HashMap<>();

        User user = repo.findByEmail(email);
        if (user == null) {
            response.put("error", "Invalid Email");
            return response;
        }

        // Check password
        if (BCrypt.checkpw(password, user.getPassword())) {
            String token = jwtUtil.generateToken(user.getEmail(), user.getRole());
            response.put("token", token);
            response.put("user", user);
            return response;
        } else {
            response.put("error", "Invalid Password");
            return response;
        }
    }
}