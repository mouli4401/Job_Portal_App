package com.mahmudalam.jobportal.spring_boot_job_portal_app.interfaces;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.mahmudalam.jobportal.spring_boot_job_portal_app.model.User;

public interface UserRepo extends MongoRepository<User, String> {
    User findByEmail(String email);
}
