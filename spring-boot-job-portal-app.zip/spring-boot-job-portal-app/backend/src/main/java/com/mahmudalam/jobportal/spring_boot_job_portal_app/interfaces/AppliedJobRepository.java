package com.mahmudalam.jobportal.spring_boot_job_portal_app.interfaces;

import com.mahmudalam.jobportal.spring_boot_job_portal_app.model.AppliedJob;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AppliedJobRepository extends MongoRepository<AppliedJob, String> {
    
    // ✅ ALL REQUIRED METHODS
    List<AppliedJob> findByUserId(String userId);
    Optional<AppliedJob> findByUserIdAndJobId(String userId, String jobId);
    List<AppliedJob> findByJobId(String jobId);
    long countByJobId(String jobId);
}